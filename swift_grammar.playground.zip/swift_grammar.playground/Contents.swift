import UIKit

let rect = CGRect(x: 1, y: 1, width: 100, height: 100)

// print : 메시지를 출력해주는 함수
print(rect)
// dump : print보다 좀더 디테일하게 출력
dump(rect)


//MARK: 이름 생성 규칙

// 영문, 숫자, 한글, 한자, 특수문자, 이미지 용 바이너리 코드 모두 사용 가능
// 예약어는 사용할 수 없지만 예약어를 작은 따옴표 나 큰 따옴표로 감싸면 가능
// 연산자는 이름으로 사용할 수 없습니다.
// 숫자로 시작할 수 없으며 특수문자는 _로만 시작 가능
// 중간에 공백은 안됨


//MARK: Escape Sequence(제어문자)
// \다음에 영문자 나 기호 하나를 추가해서 특별한 의미를 부여한 문자
// \n : 줄 바꿈
// \t : 탭
// \r : 캐리지 리턴 - 커서를 맨 앞으로 옮겨 줍니다. \n 으로 줄바꿈에 안되면 \r\n 이라고 설정
// \0: null - nil(swift)
// \\, \’, \”: \, ‘, “


//MARK: 산술 연산자
// %, *, /, +, -
// 숫자 데이터만 사용할 수 있는 연산자로 %는 정수만 가능(실수에서 나머지를 구하고자 할 때는 truncatingRemainder 메소드 이용)
// 숫자 데이터의 자료형이 다르면 연산이 불가능하므로 형 변환을 해서 수행
// % 가 나머지 구해주는 연산자인데 주기적인 작업을 반복할 때 이용

// 짝수와 홀수를 1초에 한번씩 번갈아가면서 출력
for i in 1...10 {
    if i % 2 == 1 {
        print("홀수")
    } else {
        print("짝수")
    }
    sleep(1)
}

// 빨강 파랑 검정을 1초마다 번갈아가면서 10번 출력
for i in 1...10 {
    if i % 3 == 1 {
        print("빨강")
    } else if i % 3 == 2 {
        print("파랑")
    } else {
        print("검정")
    }
    sleep(1)
}


//MARK: Overflow, Underflow
// Overflow : 저장하고자 하는 범위를 위쪽으로 넘어선 경우
// Underflow : 저장하고자 하는 범위를 아래쪽으로 넘어선 경우

// &+, &-, &*를 이용하면 Overflow 나 Underflow가 발생했을 때 반대편 끝 숫자로 이동해서 처리 - 앞쪽의 비트를 제거하고 연산
var x : Int32 = 2100000000
var y : Int32 = 1000000000

// 숫자의 표현범위를 넘어서서 에러가 발생
// var OverflowResult : Int32 = x + y

// Overflow가 발생하면 앞의 숫자로 돌아가서 계속 진행
var OverflowResult : Int32 = x &+ y

print(OverflowResult)


//MARK: 비교 연산자
// >,>=, <, <= : 크기 비교 연산자
// ==, !=, ===, !== : 항등 연산자 - 동일성 여부

// 크기 비교는 숫자 데이터와 문자 데이터 에서만 가능
// 문자 데이터는 코드 값을 가지고 저장이 되기 때문에 코드 값을 가지고 크기 비교가 가능함
// 숫자(48 부터 시작) < 대문자(65 부터 시작) < 소문자(97부터 시작)
print("swift" < "SWIFT") //소문자가 크기 때문에 false

let str1 = NSString(format: "%@", "Hi Adam")
let str2 = NSString(format: "%@", "Hi Adam")

// ==는 값을 비교하는 연산자(가르키는 곳의 값이 같은지 비교)
// ===는 참조를 비교한는 연산자(가르키는 곳이 같은지 비교)

//2개의 내용이 같은지 비교
print(str1 == str2) //true

//2개의 참조가 같은지 비교
print(str1 === str2) //각각 초기화 메서드를 이용하기 때문에 참조는 같을 수도 혹은 다를 수도 있음

//범위 ~= 데이터 : 데이터가 범위 안에 속하면 true 아니면 false를 리턴
print(1...100 ~= 50) //true
print(1...100 ~= 150) //false


//MARK: 조건 논리 연산자
// !, &&, ||
// ! : Bool 데이터의 값을 변경하는 연산자 , true->false, false->true
// &&(and) : 2개의 값이 모두 true 일 때 만 true를 리턴하고 그 이외의 경우는 false를 리턴
// ||(or) : 2개의 값이 모두 false 일 때 만 false를 리턴하고 그 이외의 경우는 true를 리턴
// and의 경우는 첫번째 데이터가 false 이면 뒤의 데이터 값에 상관없이 false 이므로 뒤의 데이터를 확인하지 않음
// or의 경우는 첫번째 데이터가 true 이면 뒤의 데이터 값에 상관없이 true 이므로 뒤의 데이터를 확인하지 않음
// &&와 || 는 데이터의 순서는 변경해도 결과는 같음
// &&가 || 보다 우선순위가 높음

// 1~100까지 3의 배수이면서 4의 배수인 데이터를 출력
for i in 1...100 {
    // &&는 앞의 데이터가 true이면 뒤의 데이터를 확인
    // i % 3이 true인 경우는 33번
    if i % 3 == 0 && i % 4 == 0 {
        print("\(i)는 3의 배수이면서 4의 배수")
    }
}
print("========================")
for i in 1...100 {
    // i % 4이 true인 경우는 22번
    if i % 4 == 0 && i % 3 == 0 {
        print("\(i)는 3의 배수이면서 4의 배수")
    }
}


//MARK: 비트 논리 연산자
// 정수 데이터를 2진수로 변환해서 비트 단위로 연산을 수행하는 연산자
// ~ : 1의 보수를 구해주는 연산자 - 1의 보수는 0은 1로 1은 0으로 변환하는 것
// ~은 1의 보수를 구해주는데 숫자 데이터를가지고 하면 절대값이 1 커지거나 작아지면서 부호가 변경됩니다.

// & : 둘 다 1일 때만 1이고 나머지 경우는 0

// | : 둘 다 0일 때만 0이고 나머지 경우는 1

// ^(eXclusive OR) : 두 개의 비트가 같으면 0 이고 다르면 1

// << : 왼쪽의 데이터를 오른쪽의 숫자만큼 왼쪽으로 이동

// >> : 왼쪽의 데이터를 오른쪽의 숫자만큼 오른쪽으로 이동

// 그래픽 프로그래밍 이나 임베디드 프로그래밍, 시스템 프로그래밍에서 많이 이용
// 23 : 00000000 00000000 00000000 00010111
// 24 : 00000000 00000000 00000000 00011000
// 23 & 24 :  00000000 00000000 00000000 00010000  -> 16
// 23 | 24 :   00000000 00000000 00000000 00011111 -> 16 + 8 + 4 + 2 + 1 : 31
// 23^24 :   00000000 00000000 00000000 00001111 -> 8 + 4 +  2 + 1 : 15
// 23 << 2 : 00000000 00000000 00000000 01011100 -> 64 + 16 + 8 + 4 : 92 -> 23 * 4
// 23 >> 2 : 00000000 00000000 00000000 00000101 -> 4 + 1 -> 5 -> 23 / 4(나머지 소멸)
print(~23) // -24 양수는 절대값이 1증가
print(~(-23)) // +22 음수는 절대값이 1감소
print(23 & 24)
print(23 | 24)
print(23 ^ 24)
print(23 << 2)
print(23 >> 2)

// 그래픽 프로그램에서 그림을 그릴 때 페인트 모드가 있는데 XORPen, NOTXORPen 등이 있습니다.

// 선을 그리고 따라서 선을 그리면 선이 지워집니다.
// 기존 선에 NOTXORPEN 을 이용해서 합성해서 그립니다.
// 2개의 선의 데이터가 동일하기 때문에 결과는 모두 1이 됩니다. 색상은 모두 1이면 흰색입니다.

// 시스템 프로그래밍에서 삭제 작업(Masking)은 0 과의 AND 입니다.
// 데이터 복사 작업이나 쓰기 작업은 기존 디스크에 데이터 와 OR 합니다.

// ~은 1의 보수를 구해주는데 절대값이 1증가하거나 감소하고 부호가 반대로 됩니다.
// 컴퓨터는 2의 보수 방법을 이용해서 음수를 저장하고 2의 보수는 1의 보수 + 1 이기 때문입니다.


//MARK: 삼항 연산자
// Bool이 나오는 표현식 ? 참일 때 표현식 : 거짓일 때 표현식
// 제어문의 if와 유사한 역할이지만 연산자입니다.
// 조건에 따라 대입받는 값이 다를 때 많이 이용

//MARK: 복합 할당 연산자
// 연산자 =을 붙이는 구조인데 왼쪽의 변수에 저장된 데이터와 오른쪽의 데이터를 연산자로 연산을한 후 왼쪽의 변수에 대입합니다.

var n : Int = 19

n += 2 //x = x + 2 -> 21이 x에 저장됩니다.

// swift 에는 ++, — 가 없어졌습니다. (Swift 3에서 제거됨)


//MARK: Optional(nil을 저장할 수 있는 데이터) 연산자
// Optional! : 강제로 값을 추출
// Optional? : 안전하게 값을 추출


//MARK: nil 연산
// 표현식1 ?? 표현식2
// 표현식1이 nil 이면 표현식2를 반환
// 기본값 설정에 많이 이용
var nilInt : String? = nil
let resultNilInt = nilInt ?? "nil이네요"
print(resultNilInt)


//MARK: 범위 연산자
// 시작숫자. . .종료숫자: 시작숫자부터 종료숫자까지
// 1~100까지 3의 배수이면서 4의 배수인 데이터를 출력
for i in 1...10 {
   print(i)
}
// 시작숫자. . <종료숫자: 시작숫자부터 종료숫자 이전까지
for i in 1..<10 {
   print(i)
}
// 숫자를 감소시키고자 할 때는 reversed()를 호출 : (시작숫자. . .종료숫자).reversed()
for i in (1...10).reversed() {
   print(i)
}


//MARK: 제어문
//자료형 명시
let score : Int = 79
//자료형 추론
let year = 2021

//MARK: if문
// score가 60 이상이면 합격이라고 출력
// 등가분할 테스트(Equivalence Partitioning)
if score >= 60 {
    print("합격")
}

// year가 윤년이면 "윤년" 출력하고 아니면 "윤년이 아님" 출력
// 윤년 - 4의 배수이고 100의 배수는 아닌 경우 또는 400의 배수인 경우
if year % 4 == 0 && year % 100 != 0 || year % 400 == 0 {
    print("\(year)은 윤년")
} else {
    print("\(year)은 윤년이 아님")
}

// score가 90 이상 100이하이면 A
// 80 이상 90미만이면 B
// 70 이상 80미만이면 C
// 60 이상 70미만이면 D
// 0 이상 60미만이면 F
if score >= 90 && score <= 100 {
    print("A")
} else if score >= 80 && score < 90 {
    print("B")
} else if score >= 70 && score < 80 {
    print("C")
} else if score >= 60 && score < 70 {
    print("D")
} else if score >= 50 && score < 60 {
    print("F")
} else {
    print("잘못된 점수")
}
// 위에 제어문은 경계값 분석(BOUNDARY VALUE ANALYSIS)을 통해 테스트해봐야 함
// 경계값 분석(BOUNDARY VALUE ANALYSIS) - 테스트 아이템의 입력 또는 출력이 여러 영역으로 구분되는 경우에 적용 입력 또는 출력 조건의 경계를 기준으로 데이터를 선택해 테스트하는 기법

// TDD : 테스트 주도 개발
// Agile : 프로그램을 분할해서 반복적인 개발 - 고객의 니즈 변화를 빠르게 적요ㅛㅇ하기 위해서 짧은 주기를 가지고 프로그램을 분할해서 정복한 후 다음 작업을 진행하는 방식
// Code Review : 작성한 코드를 분석해서 문제점을 찾아내는 것 - Code Optimizing하거나 Customizing을 수행

//MARK: switch문
/*
switch 표현식 {
case match1:
    표현식이 match1일때 수행할 내용
case match1:
    표현식이 match1일때 수행할 내용
default:
 일치하는 값이 없을 때 수행
}
*/
// 표현식의 데이터가 enum이 아니면 default 생략 불가능
// 표현식의 결과가 어떤 값과 match가 되면 break됨(스위프트에서는 break를 쓰지 않는다)
// 아래로 내려가고자 하는 경우 fallthrough를 입력해야함
// case에 하나의 값 이상 표현 가능 -,로 구분하거나 범위 연산자(..., ..<)를 이용

// case에 where를 추가 가능
// 비교 대상에 튜플(여러 데이터의 모임 - 데이터 종류에 상관없음) 사용 가능

// 가장 일반적인 경우
let menu = 1

// menu의 값이
// 1이면 나주식당
// 2이면 난향
// 3이면 신촌설렁탕
switch menu {
case 1:
    print("나주식당")
case 2:
    print("난향")
case 3:
    print("신촌설렁탕")
default:
    print("편의점")
}

// case에 where을 추가해서 조건을 추가하는 것이 가능
// score가 90 이상 100이하이면 A
// 80 이상 90미만이면 B
// 70 이상 80미만이면 C
// 60 이상 70미만이면 D
// 0 이상 60미만이면 F
switch score {
case 90...100:
    print("A")
case 80..<90:
    print("B")
case 70..<80:
    print("C")
case 60..<70:
    print("D")
case 0..<60:
    print("F")
default:
    print("잘못된 점수")
}

//MARK: for문
// 데이터 모임을 순회할 때 사용
/*
for 임시변수 in 데이터 모임 또는 범위 {
    데이터모임을 순회하면서 수행할 작업
}
*/
for i in 0...2 {
    print(i)
}

// 범위의 값을 대입하지 않고 실행
for _ in 0...2 {
    print("임시변수 이용하지 않고 순회")
}

var li = ["CBD", "TDD", "Agile"]
for swengineering in li {
    print(swengineering)
}


//MARK: while문
/*
while 표현식 {
    수행할 내용
}
 표현식의 결과가 false가 아니라면 수행할 내용을 반봅
*/

var i=0
while i <= 2 {
    print("반복 수행")
    i = i + 1
}

//MARK: repeat while문
/*
repeat {
    수행할 내용
} while 표현식
 표현식의 결과가 false가 아니라면 수행할 내용을 반봅
*/

//MARK: guard문
// 표현식이 거짓일 때 수행할 문장을 작성하는 제어 명령어
/*
guard 표현식 else {
    수행할 내용
}
*/
// 표현식이 false일 때 수행할 내용을 작성
// else 안은 종료하는 문장을 작성
// 조건에 맞지않으면 준단하겠다는 의미로 사용

let os = 9.0

//if는 흐름을 이어가는데 분기를 해야할 때 사용
if os < 11.0 {
    print("11.0 보다 작음")
}

//guard는 함수 안에 포함되어야 함
//흐름을 중단 시키기 위해 사용 (if하고 반대로 작용)
func function1() {
    guard os >= 11.0  else {
        print("11.0 보다 작음")
        return
    }
}
function1()

//MARK: 운영체제 버전 확인
print("윤영체제 버전: \(UIDevice.current.systemVersion)")

//특정 운영체제 이상에서 동작하기
if #available(OSX 11.0, *) {
    print("11.0 이상에서 동작")
} else {
    print("11.0 미만에서 동작")
}

//MARK: Optional
// Swift 나 Kotlin에서는 자료형을 구분할 때 nil을 저장할 수 있는 자료형과 그렇지 않은 자료형으로 구분
// nil을 저장할 수 있는 자료형을 Optional이라고 함
// null 안정성 때문에 제공

// Optional 자료형이 아닌경우 NullPointerExcetion이 발생하지 않음
var notOptional : Int = 123

// Optional 자료형
var optional : Int? = nil

// Optional 자료형과 Optional 자료형이 아닌경우는 연산이 불가능
// print(notOptional + optional) //error

// Optional 사용
// 1)명시적 해제 - 강제 해제
// =>강제로 Optional을 벗겨내는 것으로 Optional 데이터 뒤에 !를 붙이면 됩니다,
// =>저장된 데이터가 nil 이라면 에러가 발생합니다.
// 이 방법을 사용할 때는 nil 인지 확인하고 사용하는 것이 좋습니다.

// 2)명시적 해제 - 비강제 해제
// =>Optional Binding 이라고 하는데 if 나 guard 구문에서 다른 변수에 대입을 하게되면 nil 이 아니면 true를 리턴하고 nil 이면 false를 리턴하므로 true 일 때 사용하는 방식입니다.

// Optional 변수 생성
var optionaX : Int! =  32
print("x:\(optionaX)")
// Optional을 강제로 해제하고 사용
print("x:\(optionaX!)")

optionaX = nil
// nil 이 있는 데이터를 강제로 변경해서 연산에 사용하면 에러
// nil 인지 확인하고 강제 변환을 해야 합니다.
if optionaX != nil{
    let optionaXResult = optionaX! + 20
    print("optionaXResult:\(optionaXResult)")
}else{
    print("optional가 nil 이라서 연산에 사용할 수 없습니다.")
}


// Optional 데이터를 if 구문의 표현식에서 다른 변수에 대입해서 해제
// 변수에 대입을 하게 되면 nil 이 아니면 true를 리턴하고 nil 이면 false 리턴
if let optionaY = optionaX{
    print("optionaY:\(optionaY)")
}else{
    print("optionaX는 nil")
}

// 3)컴파일러에 의한 자동 해제
// => == 또는 != 연산자를 이용할 때는 자동으로 해제해서 비교를 수행합니다.

// 4)변수를 선언할 때 ? 대신에 ! 연산자를 이용해서 선언하면 사용할 때 해제를 하지 않아도 자동으로 해제가 됩니다.
var optionaX2 : Int? = 123

// == 연산자 나 != 연산자를 사용할 때는 Optional을 강제로 해제하지 않아도 됩니다.
if optionaX2 == 123{
    print("2개의 데이터는 일치합니다.")
}else{
    print("2개의 데이터는 일치하지 않습니다.")
}

// 사용할 때 자동으로 !를 해제해서 사용하도록 변수를 생성
var optionaY2 : Int! = 123
//x는 ?를 붙여서 선언한 것으로 !로 해제해서 사용
//y는 !를 붙여서 선언한 것으로 !를 해제하지 않아도 됩니다.
print(optionaX2! + optionaY2)

//nil 연산자
//데이터가 nil 이면 뒤의 데이터를 사용하고 nil 이 아니면 원본 데이터 사용
print(optionaX2 ?? 256)
optionaX2 = nil
print(optionaX2 ?? 256)

//MARK: **특수 자료형
//1.Any
//=>모든 데이터의 참조를 저장하기 위한 자료형으로 Objective-C 의 자료형

//2.AnyObject
//=>모든 인스턴스(클래스로부터 생성된 것)의 참조를 저장하기 위한 자료형으로 Objective-C 의 자료형

//3.Any 나 AnyObject 에 저장할 때는 아무 데이터나 저장할 수 있지만 사용을 할 때는 강제 형 변환을 해서 사용해야 합니다.

//4.Selector
//=>Objective-C에서 사용하던 것으로 함수를 저장하기 위해서 사용
//=>Swift 에서는 이 자료형이 필요가 없습니다.
//Swift 는 함수형 프로그래밍 언어라서 함수 자체가 하나의 자료형입니다.
//Objective-C API 에서 사용 - 콜백 메소드 지정하는데 사용

//5.Never
//=>함수의 리턴 타입으로만 사용되는 자료형으로 함수가 정상적으로 리턴하지 않을 수 도 있다라는 의미를 전달하기 위해서 사용

var optionaX3 : Any = 123

//Any 자료형의 데이터는 사용을 할 때 원래의 자료형으로 되돌려서 사용해야 합니다.
//이 때는 as , as?, as! 를 이용합니다.
//print(optionaX3 + 256)
print((optionaX3 as! Int) + 256)

// **함수
//=>독립적으로 메모리를 할당받아 수행되는 작은 프로그램 - 단독으로 존재할 수 없고 파일이나 클래스 안에 존재해야 합니다.
//클래스 안에 존재하면 Method 라고 합니다.

//1.분류
//=>사용자 정의 함수: 개발자가 필요에 의해서 만든 함수
//=>API(Application Programming Interface - Software Develpment Kit): 언어 나 프레임워크 제조사에서 제공해주는 함수
//=>3rd Party Function: 다른 개발자가 만들어서 제공하는 함수

//2.함수 와 메소드
//=>함수는 전역에 생성해서 모든 곳에서 호출이 가능
//=>메소드는 클래스 안에 만들어서 호출할 수 있는 범위가 한정적이고 호출을 하기 위해서는 클래스 나 인스턴스 와 같은 Receiver 가 필요합니다.

//3.함수의 구성
//1)이름: 함수를 구분하기 위한 이름
//2)매개변수(Parameter, Argument): 함수를 호출해서 실행할 때 넘겨주는 데이터
//3)반환형(Return Type): 함수의 수행이 끝나고 호출한 곳으로 돌아갈 때 가져가는 데이터의 자료형으로 없으면 Void 나 생략
//4)함수의 내용(body): 함수가 수행할 내용

//4.함수 작업 구조
//1)함수를 선언 - 생성

//2)함수를 호출 - 새로운 메모리 공간을 할당받아서 실행하고 결과를 리턴

//3)결과를 사용

//5.함수를 사용하는 이유
//1)코드의 중복을 제거해서 유지 보수를 쉽게 하기 위해서 - 변수, 반복문, 함수, 클래스, 상속의 공통된 이유

//2)적절하게 코드를 분리해서 가독성 높이고 메모리 효율을 증가시키기 위해서


//6.함수 선언 - 구현, 정의
//func 함수이름(매개변수이름:매개변수의  자료형, …..) -> 리턴 타입{
//    함수의 내용
//    return 데이터
//}
//=>매개변수는 없으면 생략 가능 - ( )는 남겨둠
//=>리턴되는 데이터가 없을 때는 Void 또는 -> 리턴 타입을 생략
//=>함수 내용은 없을 수 도 있지만 없으면 아무일 도 하지 않습니다.
//=>리턴 타입이 Void 이거나 생략되어 있으면 return 문장을 생략할 수 있고 return 만 사용할 수 도 있습니다.
//return 이후에는 실행문이 나오면 안됩니다.
//return 은 호출한 곳으로 돌아가는 명령어라서 메모리가 소멸됩니다.

//7.함수 호출
//변수 = 함수이름(넘겨줄 데이터 나열)
//=>함수를 선언할 때 만든 매개변수와 자료형을 일치시켜서 데이터를 넘겨주어야 합니다.
//=>리턴 타입이 없으면 변수에 대입하면 안됩니다.
//=>리턴되는 데이터가 있을 때 변수에 저장하지 않고 다른 명령어에 바로 사용해도 됩니다.

//매개변수가 없고 리턴이 없는 함수 생성
func disp(){
    for _ in 0..<5{
        print("Hello Swift")
    }
}

//매개변수가 없고 리턴이 없는 함수를 호출
disp()


//8.매개변수 - parameter, argument, query string(web)
//=>함수를 호출할 때 함수에게 넘겨주는 데이터
//=>매개변수는 함수 내에서만 사용할 수 있는 지역 변수로 생성되고 읽기 전용으로 생성됩니다.
//=>함수에 따라서 없을 수 도 있으며 없을 때는 ( )만 합니다.
//=>swift 에서는 함수를 호출할 때 매개변수의 이름과 값을 같이 넘겨주어야 합니다.
//함수이름(매개변수이름:값..) 의 형태로 대입합니다.
//=>Apple 의 API의 매개변수의 이름을 길게 만듭니다.

//매개변수를 받아서 매개변수 만큼 출력해주는 함수
func disp(count:Int){
    for _ in 0..<count{
        print("Hello Function")
    }
}

//함수를 호출할 때 매개변수는 이름과 함께 설정합니다.
disp(count: 3)
disp(count: 5)

//매개변수가 2개 인 함수 - message를 count 횟수 만큼 출력해주는 함수
func disp2(message:String, count:Int){
    for _ in 0..<count{
        print(message)
    }
}

disp2(message: "매개변수가 여러 개", count: 2)

//1)Overloading(중복 정의)
//=>동일한 영역에 함수의 이름은 같고 매개변수의 개수나 자료형 또는 순서를 다르게 만든 함수가 2개 이상 존재하는 경우

//2)매개변수 이름에 별칭 사용
//=>외부에서 사용하는 이름 과 함수 내부에서 사용하는 이름을 다르게 만드는 것
//외부에서 보는 이름은 길게 사용자가 알아보기 쉽게 해주는 것이 좋고 내부에서 사용하는 이름은 짧게 하는 것이 코딩하는데 편리하기 때문입니다.

//func 함수이름(외부에서사용할이름 내부에서사용할이름 : 자료형….)

//3)외부에서 입력할 때 매개변수의 이름을 생략
//=>첫번째 매개변수는 작업을 위한 데이터일 때 가 많기 때문에 생략하도록 할 수 있습니다.
//=>매개변수 이름을 _로 하면 됩니다.
//내부에서 사용할 거라면 내부에서 사용할 이름이 반드시 있어야 합니다.

//외부에서는 message 와 count 라는 이름으로 매개변수를 대입
//내부에서는 msg 와 cnt로 매개변수를 사용합니다.
func disp3(message msg : String, count cnt:Int){
    for _ in 0 ..< cnt{
        print(msg)
    }
}

disp3(message: "외부에서 사용한 이름", count: 5)
//disp3(msg: "외부에서 사용한 이름", cnt: 5)
//에러 - 내부에서 사용하는 이름 사용 못함


//외부에서는 이름을 생략해서 msg를 대입
func disp4(_ msg:String){
    print(msg)
}

disp4("이름없이 매개변수 대입")
//=>매개변수 생략은 첫번째 데이터 1개만 사용하는 것이 일반적입니다.

//4)매개변수에 기본값 설정
//func 함수이름(매개변수이름:자료형 = 기본값…)
//=>매개변수를 생략하면 기본값이 설정됩니다.
//=>뒤에서부터 사용합니다.


//5)매개변수의 개수를 제한없이 설정
//func 함수이름(매개변수이름: 자료형 …)
//=>대입되는 개수를 설정하지 않은 것으로 여러 개 대입 가능
//=>내부에서는 매개변수이름을 데이터 집합으로 간주하기 때문에 for - in을 이용해서 데이터를 순차적으로 접근하는 것이 가능

//매개변수에 기본값을 설정한 함수
func disp5(message:String = "nomessage"){
    print(message)
}

disp5(message:"message")
//매개변수가 없어서 nomessage 출력
disp5()

//매개변수의 개수가 가변인 함수
func sum(data:Int...){
    var tot = 0
    for i in data{
        tot = tot + i
    }
    print(tot)
}

sum(data:10, 20)
sum(data:10, 20, 30)


//6)매개변수에 레퍼런스 전달
//=>매개변수는 읽기 전용으로 값이 전달되기 때문에 함수 안에서 외부에서 대입한 매개변수의 값을 변경할 수 없습니다.
//Call by Value 라고 합니다.
//=>함수 내부에서 함수 외부의 데이터를 변경하고자 할 때는 매개변수를 대입할 때 레퍼런스를 대입해주어야 합니다.
//Call by Reference 라고 합니다.
//=>함수를 만들 때 함수의 매개변수 앞에 inout을 추가합니다.
//=>함수를 호출할 때 매개변수 의 값 앞에 & 를 추가하면 됩니다.

//매개변수가 Value 형태로 대입받기 때문에 함수에서 외부의 데이터를 변경할 수 없음
func callByValue(arg:Int){
    //arg = 20 //읽기 전용으로 전달되므로 직접 변경하는 것은 에러
    var param = arg
    param = 20
    print("param:\(param)")
}

var referenceX : Int = 10

callByValue(arg: referenceX) //x가 대입된 것이 아니고 x의 데이터인 10이 대입된 것
print("referenceX:\(referenceX)")

//레퍼런스를 전달받는 함수
func callByReference(arg: inout Int){
    arg = 20
    print("arg:\(arg)")
}
callByReference(arg: &referenceX) //x의 참조가 전달 - //x의 값이 변경될 수 있음
print("referenceX:\(referenceX)")


//9.return
//=>return 은 함수의 수행을 종료하고 함수를 호출한 곳으로 제어권을 이동시키는 제어문

//1)return type
//=>함수를 호출하는 곳으로 제어권을 넘겨줄 때 가지고 가는 데이터의 자료형
//=>가지고 갈 데이터가 없으면 Void 또는 생략
//=>함수의 내용이 한 줄 이고 이 데이터를 리턴하는 경우 return을 생략할 수 있음


//2)return 은 1개만 가능
//=>여러 개를 리턴하고자 하는 경우는 데이터의 모임을 만들어서 리턴
//리턴이 있는 함수
func add(first:Int, second:Int) -> Int{
    return first + second
}

//리턴이 있는 함수는 호출 결과를 변수에 담아서 사용
var returnResult = add(first: 100, second: 300)
print("returnResult:\(returnResult)")

//10.Swift 에서 함수는 일급 객체
//=>함수도 하나의 자료형
//=>함수도 하나의 자료형 이므로 변수를 생성할 수 있고 다른 함수의 매개변수가 될 수 있고 함수의 리턴 타입이 될 수 있습니다.
//함수가 다른 함수의 매개변수가 되는 경우는 함수가 콜백으로 사용되는 경우입니다.
//콜백 함수는 이벤트가 발생했을 때 호출되는 함수입니다.

//=>함수의 자료형 표현
//(매개변수의 자료형, 매개변수의 자료형..) -> 리턴타입

//=>함수 안에 함수를 만들 수 도 있고 클래스를 만들 수 도 있습니다.

//=>순수 함수: 외부의 영향을 받지도 영향을 주지도 않고 리턴을 하는 함수 - 매개변수의 자료형이 Value Type으로 값을 전달받는 함수

//이 함수는 매개변수가 없고 리턴이 없는 함수를 매개변수로 요청
func callback(f:()->Void){
    f()
}

func method(){
    print("함수를 매개변수로 대입합니다.")
}

//함수를 매개변수로 대입해서 callback을 호출
callback(f:method)

//매개변수를 함수로 받는 함수
//정수 2개를 매개변수로 받고 정수를 리턴하는 함수가 매개변수
func ff(f:(Int, Int) -> Int){
    print(f(100, 200))
}


func add2(first:Int, second:Int) -> Int{
    return first + second
}

ff(f:add2)

//MARK: **함수
//1.Operator Overloading(연산자 오버로딩)
//=>Python 이나 Kotlin에서도 가지고 있는 개념
//=>연산자를 하나의 함수로 취급
//=>연산자의 기능을 사용자가 원하는 형태로 변경하는 것
//=>Java 에서 + 가 연산자 오버로딩을 적용한 대표적인 예
//+ 를 학습할 때는 숫자 사이의 더하기 연산을 위한 연산자라고 배웠는데 문자열에 + 연산을 하면 문자열과 결합을 한다고 합니다.
//기존 연산자의 기능을 변경해서 String의 인스턴스에 적용

//1)연산자의 분류
//=>데이터와 연산자의 순서에 따른 분류
//prefix: 연산자가 앞에 오는 경우 - 부호 로서의 + 와 -
//postfix: 연산자가 뒤에 오는 경우 - ?, !
//infix: 연산자가 데이터 사이에 위치하는 경우

//2)연산자 중복 정의 형식
////연산자가 없는 경우는 선언
//분류방식 operator 연산자
//
//분류방식 func 연산자(value: 자료형) -> 리턴타입{
//    return 데이터
//}
//
//=>Infix 연산자는 func 을 만들 때 매개변수를 2개 주어야 합니다.
//선언할 때도 : MultiplicationPrecedence 라고 추가해 주어야 합니다.

//새로운 연산자를 선언 - 전위 연산를 재정의 - 후위로 하고 싶으면 prefix를 postfix로 변경하고
//연산자를 호출할 때 연산자를 뒤에 사용하면 됩니다.
prefix operator **

//**의 기능을 생성
prefix func **(value:Int) -> Int{
    return value * value
}

print(**100)

//중위 연산자 재정의
infix operator ** : MultiplicationPrecedence

//** 의 기능을 정의
//lhs 라고 이름을 정한 이유는 왼쪽의 데이터이고 rhs 라고 이름을 정한 이유는 오른쪽의 데이터라는 의미입니다.
func **(lhs:Int, rhs:Int) -> Int{
    var tot = 1
    for _ in 1...rhs{
        tot = tot * lhs
    }
    return tot
}

print(3 ** 5)


//2.Nested Function(내부에 선언된 함수)
//=>Swift 는 함수를 일급 객체로 취급하기 때문에 함수 안에 함수 나 클래스를 만들 수 있습니다.
//변수에 대입하는 것도 되고 함수의 매개변수로 사용할 수 있고 리턴 타입으로도 사용할 수 있습니다.
//=>만드는 목적은 함수를 리턴해서 함수 내의 지역 변수의 값을 수정하기 위해서 사용합니다.
//이러한 목적으로 만든 내부 함수를 Closure 라고 합니다.
//Swift 에서는 Closure 가 람다의 의미로 사용됩니다.

//매개변수가 없고 리턴하는 데이터도 없는 함수를 리턴하는 함수
//리턴이 없는 경우는 swift 와 kotlin 에서 리턴 타입을 생략해도 됩니다.
func method2() -> (() -> Void){
    var x = 10
    //내부 함수를 만들어서 외부 함수의 지역 변수 값을 변경하고 출력
    func inner() -> Void{
        x = x + 1
        print("x:\(x)")
    }
    
    //내부 함수를 리턴
    return inner
}

//메소드의 호출하고 리턴되는 데이터인 method 안의 inner 함수의 내용이 f에 대입됩니다.
let f = method2()

f()
f()

//=>함수 내에서만 사용할 목적으로 생성

//MARK: 3.Closure
//=>이름이 없는 함수 - 다른 언어에서는 보통 람다라고 합니다.
//=>함수를 매개변수로 대입하고자 할 때 별도의 함수의 이름을 정해서 만들고 대입하게 되면 이름을 가진 객체는 정적으로 생성해서 메모리에 유지를 합니다.
//현재 사용하지 않는데 메모리를 차지하는 경우가 발생할 수 있습니다.
//사용을 할 때 생성해서 사용하는 방식으로 메모리를 절약하기 위해서 사용되는 문법입니다.
//자바에서 어떤 인터페이스를 구현하거나 클래스를 상속할 때 별도의 클래스를 만들지 않고 이름없는 클래스를 만들어서 사용하는 것도 같은 이유입니다.
//new View.OnClickListener(){메소드 구현}

//1)생성
//{(매개변수 나열) -> 리턴 타입 in 수행할 내용}
//=>매개변수가 없고 리턴타입이 없고 내용이 한 줄 이라면 () -> 리턴타입 in 을 생략할 수 있습니다.
////기존의 함수를 생성하는 방식
func function() -> Void{
    print("기존의 함수를 만드는 방식")
}

//동일한 기능을 하는 closure를 생성
var closure = {
    () -> Void in
    print("람다를 이용한 함수 생성")
}

function()
closure()

//2)특징
//=>매개변수의 자료형을 생략 가능
//=>매개변수를 생략하고 코드 내에서 $0, $1 등의 형태로 매개변수를 사용할 수 있습니다.
//정수 2개를 매개변수로 받아서 더한 값을 리턴해주는 클로져
/*
var closure = {(first, second) -> Int in
    return first + second
}
*/

//매개변수의 자료형을 생략하는 것이 가능 - 클로저를 호출할 때 대입된 데이터를 가지고 자료형을 추론
//iOS 나 Mac OS X 용 애플리케이션을 개발할 때 코드 센스 만으로 개발이 어렵게 되는 이유 중 하나
/*
var closure = {(first, second) -> Int in
    return first + second
}
*/


//매개변수의 이름을 대신 내용 안에서 $0, $1 이런 형태로 사용이 가능
//지금은 에러 - $0 의 형태를 연산에 사용할 수는 없습니다.
/*
var closure = {() -> Int in
    return ($0 + $1)
}


print(closure(100, 200))
*/


//3)Trailing Closure
//=>어떤 함수의 매개변수가 함수(클로저)이고 마지막 매개변수라면 함수를 호출할 때 함수이름()클로저 를 만들어서 대입하는 것이 가능합니다.
//클로저를 함수 호출 안에서 만드는 것이 아니고 바깥에 만드는 문법입니다.

//list(array)의 정렬을 수행해주는 함수는 sort(by:정렬을 수행할 때 사용할 비교 함수) 입니다.
//대입해야 할 함수는 2개의 매개변수를 받아서 Bool 을 리턴하는 함수이어야 합니다.
//이 함수에서 true를 반환하면 뒤의 데이터가 크다고 생각해서 자리를 변경하지 않고 false를 리턴하면 자리를 변경합니다.

var ar = [80, 70, 75]

//함수를 만들어서 해결
/*
func mycompare(n1:Int, n2:Int) -> Bool{
    return n1 > n2
}


//사용자 정의 함수를 이용해서 데이터를 정렬
ar.sort(by: mycompare)
*/

//일반적인 클로저를 이용해서 작성
/*
ar.sort(by: {(n1:Int, n2:Int) -> Bool in return n1 > n2})
print(ar)
*/

/*
//클로저는 매개변수의 자료형 생략 가능
ar.sort(by: {(n1, n2) -> Bool in return n1 > n2})
print(ar)
*/


/*
//클로저의 내용이 return 하는 문장 만 있는 경우 매개변수와 리턴 타입을 생략하고 $0 $1 의 형태를
//이용해서 매개변수를 사용하는 것이 가능
ar.sort(by: {return $0 > $1})
print(ar)
*/


//수행되는 문장이 1개 이고 단순한 연산이라면 매개변수를 생략하고 연산자만 사용해도 됩니다.
/*
ar.sort(by: >)
print(ar)
*/

//trailing closure
//클로저가 마지막 매개변수일 때는 함수()클로저 형태로 클로저를 () 외부에 작성하는 것이 가능합니다.
//iOS API 나 Android API 에서 많이 사용합니다.

ar.sort(){(n1:Int, n2:Int) -> Bool in return n1 > n2}
print(ar)


//4)@escaping & @autoclosure
//=>클로저를 매개변수로 받으면 함수 내부에서 다른 변수에 대입해서 호출하는 것이 안됩니다.
//이것을 가능하도록 하고자 할 때 매개변수 앞에 @escaping을 붙이면 됩니다.
//
//=>@autoclosure 는 일반 구문을 closure 로 변환해주는 예약어

//4.특별한 함수 구조
//1)Never 리턴
//=>리턴 타입에 Never를 기재하면 이 함수는 정상적으로 끝나지 않는다라는 의미를 갖게 됩니다.
//비정상적인 상황에서 이 함수를 호출해서 사용자들에게 비정상적인 상황이라는 것을 알려주기 위한 용도로 사용합니다.

//2)@discardableResult
//=>이 함수의 리턴값은 무시해도 된다라는 의미를 전달하기 위한 예약어

//**객체 지향 프로그래밍 : Object Oriented Programming
//=>프로그램의 모든 것을 객체로 만들어서 사용하고 유사한 역할을 수행하는 객체들이 있다면 이를 클래스로 추상화해서 사용하는 프로그래밍 방식
//=>Swift 에서는 Class, Struct, Enum, Protocol, Extension, Inheritance, Method Overriding 을 이용해서 구현

//MARK: 1.Enum
//=>나열형 상수 또는 열거형 상수라고 합니다.
//=>연관된 항목 들을 묶어서 표현할 수 있는 사용자 정의 자료형
//=>옵션을 위한 상수들의 모임입니다.
//=>swift3 에서 swift4가 나왔을 때 iOS에서 가장 많이 변경한 부분으로 이전에는 열거형 상수의 이름을 모두 대문자로 했는데 swift4 를 적용한 iOS11 부터 열거형 상수에 이름을 모두 소문자를 사용
//=>값의 제한 때문에 사용합니다.
//=>자료형이 열거형으로 제한이 되면 열거형 이름은 생략하고 상수이름만 사용해도 됩니다.
//iOS에서는 전부 다른 클래스 나 구조체 안에서만 생성됩니다.
//?.? 형태로 매개변수를 요구하면 이 것은 전부 enum을 요청하는 것입니다.

//1)생성
//enum 열거형이름:자료형{
//    case 상수이름 = 값,
//    case 상수이름 = 값
//}
//=>값을 할당하지 않을 때는 자료형을 생략하는 것이 가능합니다.
//=>열거형으로 자료형을 생성하면 열거형 안에 포함된 상수만 대입이 가능합니다.

//2)열거형 상수 사용
//=>열거형이름.상수이름 의 형태로 사용
//=>열거형 변수에 대입할 때는 열거형이름. 은 생략해도 됩니다.

//3)열거형 상수의 저장된 값을 가져오고자 할 때는 .rawValue 를 호출하면 됩니다.

//4)내부에 메소드 생성도 가능하고 생성자 처럼 값을 입력받아서 처리하는 것도 가능합니다.
//열겨형 생성
enum MultimediaType:Int{
    case none = 0
    case text = 1
    case sound = 2
    case picture = 3
    case video = 4
}


//열거형에 값을 대입
let type : MultimediaType = .sound

print(type)
print(type.rawValue) //실제 저장하고 있는 값인 2가 출력됩니다.


//MARK: 2.구조체(Struct)
//=>사용하는 목적이나 사용법은 클래스와 유사
//=>관련있는 속성 과 기능의 집합

//1)클래스 와 공통점
//=>속성(Property) 과 기능(Method)의 집합
//=>서브스크립트([“이름”]) 가능
//=>초기화 메소드 소유 - init
//=>확장 가능 - extension
//=>인터페이스 사용 가능 - protocol

//2)클래스 와 다른점
//=>구조체는 다른 변수에 대입하면 값을 복사하지만 클래스는 참조를 복사합니다.
//구조체는 다른 변수에 대입하면 동일한 값을 갖는 인스턴스가 2개가 되지만 클래스는 다른 변수에 대입해도 인스턴스는 1개 입니다.
//=>클래스는 상속이 가능합니다.
//=>클래스는 소멸자(인스턴스가 소멸될 때 호출하는 함수) 역할을 수행하는 함수가 있습니다.
//=>클래스의 인스턴스는 참조 카운트가 있지만 구조체의 인스턴스는 참조 카운트가 없습니다.
//=>클래스는 초기화 메소드를 만들지 않으면 인스턴스를 생성할 때 값을 대입받을 수 없지만 구조체는 초기화 메소드를 만들지 않아도 모든 속성 값을 인스턴스를 생성할 때 대입 받을 수 있습니다.

//3)구조체 생성 - 사용자 정의 자료형 생성
//struct 구조체이름{
//    프로퍼티 선언
//
//    초기화 메소드
//
//   사용자 정의 메소드
//
//   서브스크립트
//
//}

//4)구조체의 인스턴스 생성
//var 또는 let 변수명 = 구조체이름(매개변수를 나열)
//
//=>모든 property 값을 기본값으로 생성 : 구조체이름()
//=>값을 대입받아서 생성: 구조체이름(이름:값, 이름:값 ….)

//5)프로퍼티나 메소드 호출
//=>구조체 내에서는 이름만으로 호출이 가능
//=>인스턴스를 이용해서 호출할 때는 변수이름.이름 의 형태로 호출합니다.

//구조체 생성 - 사용자 정의 자료형 생성
struct Point{
    //프로퍼티 선언
    //Optinal 이 아니므로 기본값이 있어야 함
    var x:Int = 0
    var y:Int = 0
    
    //메소드 선언
    func disp() -> Void{
        print("x:\(x) y:\(y)")
    }
    
}

//구조체의 인스턴스 생성
let p1 = Point()
let p2 = Point(x: 100, y: 300)

//구조체 인스턴스 사용
p1.disp()
p2.disp()


//MARK: 3.Class
//=>생성을 할 때는 구조체에서 struct 부분을 class 로 변경
//=>클래스가 생성하는 인스턴스는 참조형
//함수와 클래스의 인스턴스가 참조형
//=>클래스는 유사한 역할을 하는 객체들을 추상화 한 개념
//클래스는 모델하우스 의 개념이고 각각의 집이 인스턴스

//1)인스턴스 생성
//클래스이름-초기화메소드(파라미터를 나열)
//=>초기화 메소드는 클래스를 기반으로 프로퍼티 들을 메모리 할당한 후 참조를 리턴합니다.
//=>인스턴스를 생성하고 인스턴스를 다시 사용하고자 하는 경우에는 변수에 인스턴스의 참조를 저장합니다.
//
//var 또는 let 참조변수 : 클래스이름 = 초기화메소드(매개변수 나열)
//
//=>2개의 인스턴스가 동일한 지 여부를 확인할 때는 === 연산자 이용
//다르다는 것을 확인할 때는 !== 연산자 이용

//2)구조체 와 인스턴스의 가장 큰 차이
//=>iOS에서 좌표라던가 크기 등을 저장할 때 사용하는 것은 구조체이고 작업을 수행하는 용도로 사용되는 것들은 클래스로 제공합니다.

struct P1{
    var score:Int = 0
}

class P2{
    var score:Int = 0
}


//구조체는 값을 복사합니다.
//원본의 값이 변경이 되더라도 복사본의 값은 변경되지 않습니다.
var s1 = P1()
var s2 = s1

s1.score = 100
print(s1.score)
print(s2.score)


//클래스의 인스턴스는 참조를 복사합니다.
var c1 = P2()
var c2 = c1

c1.score = 100

print(c1.score)
print(c2.score)


//MARK: 3)Property
//=>구조체 나 클래스 내에 자신의 특성을 저장하거나 연산을 해서 사용하기 위해 선언한 것
//자바에서 클래스 안에 선언한 변수 와는 다릅니다.
//=>Property는 저장을 할 수 도 있지만 연산에 의해 생성되기도 하고 접근자 메소드를 별도로 생성하지 않고 내부에 선언할 수 있기 때문입니다.
//=>종류
//저장 프로퍼티: 데이터를 저장하기 위한 목적
//연산 프로퍼티: 연산을 수행해서 제공하는 프로퍼티 - 파생(Derived)이라는 표현을 사용하기도 합니다.
//타입 프로퍼티: 클래스가 사용가능한 프로퍼티 - 자바에서는 static
//
//=>저장 프로퍼티
//클래스 나 구조체 안에 변수 나 상수를 선언하면 저장 프로퍼티
//초기값을 설정하지 않을 거라면 Optional로 선언해야 합니다.
//Optional로 선언할 거라면 ?(wrapping을 제거하고 사용)를 사용하는 것보다는 !(사용할 때 자동으로 wrapping이 제거)를 사용해서 선언하는 것을 권장
//
//=>연산형 프로퍼티
//연산을 통해서 결과를 사용하는 프로퍼티
//자주 사용하는 연산을 연산형 프로퍼티로 만드는 것을 권장
//get을 정의해서 연산을 수행합니다.
//set은 선택적 구현 입니다.
//단순하게 값을 리턴하면 에러
//
//var 프로퍼티이름 : 자료형{
//    get{
//        return 리턴할 데이터
//    }
//   set(value){
//        수행할 내용
//    }
//}



//국어 점수 와 영어 점수를 갖는 DTO 클래스
class Temp{
    //저장 프로퍼티 - 눈에 보이지 않지만 get 과 set을 생성합니다.
    //값을 대입하면 set 이 호출되고 값을 가져오면 get 이 호출됩니다.
    var kor : Int = 0
    var eng : Int = 0
    
    //연산 프로퍼티 - 연산에 의해서 파생된다고 해서 파생 프로퍼티라고도 합니다.
    var avg : Int {
        get{
            return (kor + eng) / 2
        }
    }
}

//Temp 클래스의 인스턴스를 생성
let temp:Temp = Temp()
//프로퍼티에 값을 저장
temp.kor = 98
temp.eng = 78

//kor 과 eng 을 평균 출력
print(temp.avg)


//=>lazy init - 지연 생성
//저장 프로퍼티 나 연산 프로퍼티는 인스턴스가 생성될 때 메모리를 할당받아서 사용합니다.
//나중에 사용할 프로퍼티도 미리 메모리를 할당 받아놓고 있기 때문에 인스턴스를 여러 개 만들어 사용한다면 메모리에 부담을 줄 수 있습니다.
//지연 생성은 인스턴스가 생성될 때 메모리를 할당받는 것이 아니고 처음 사용할 때 메모리를 동적으로 할당 받도록 하는 것입니다.
//프로퍼티 앞에 lazy 만 붙이면 됩니다.

class Nest{
    init(){
        print("초기화 메소드")
    }
}

class Outer{
    //지연 생성 - 처음 호출될 때 생성
    lazy var nest:Nest = Nest()
    
    func disp(){
        print("함수 호출")
        print(nest);
    }
}


//Outer의 인스턴스를 생성
let outer : Outer = Outer()
outer.disp()

//=>Property Observer
//프로퍼티 값의 변화를 감시할 수 있는 기능
//Key value Observing 디자인 패턴이라고 하는데 데이터의 변화를 감시하고 있다가 데이터에 변화가 생기면 알려주거나 동작을 수행하기 위한 기능
//willSet 과 didSet을 정의해서 사용
//
//willSet 은 프로퍼티의 값이 변경되기 전에 호출되는 메소드, 매개변수가 하나 넘어가는데 이름은 newValue 로 변경하고자 하는 값입니다.
//
//
//didSet은 프로퍼티의 값이 변경된 후 에 호출되는 메소드, 매개변수가 하나 넘어가는데 이름은 oldValue 로 변경된 값입니다.
//
//var 또는 let 프로퍼티이름:자료형 = 초기값{
//    willSet{
//        변경되기 전에 수행하고자 하는 내용
//    }
//    didSet{
//        변경된 후에 수행하고자 하는 내용
//   }
//}
//
//데이터가 변경되기 전에 하는 일의 대부분은 유효성 검사 입니다.
//변경하고자 하는 데이터가 원하는 조건에 맞는 데이터인지 확인하는 작업을 유효성 검사라고 합니다.
//
//데이터가 변경된 후에 하는 일은 일반적으로 변경된 시간 과 값을 로깅합니다.
//
//=>클로저를 이용한 프로퍼티 초기화
//let 또는 var 프로퍼티이름:자료형 = {
//    내용
//    Return 초기화할 값
//
//
//}()
//
//=>type property
//클래스 이름으로 사용 가능한 프로퍼티
//동일한 클래스 타입으로 만들어진 인스턴스 사이에서 데이터를 공유할 목적으로 생성
//인스턴스들이 소유하고 있지 않고 클래스가 소유함
//
//프로퍼티 선언 맨 앞에  static 이나 class를 붙이면 됩니다.
//class는 저장 프로퍼티에는 사용을 못하고 연산 프로퍼티에만 사용합니다.


//MARK: 4)메소드
//=>클래스 나 구조체 또는 열거형 안에 만들어진 함수
//=>클래스 나 구조체 또는 열거형 안에 만들어진 함수를 내부에서 호출할 때 바로 호출이 가능합니다.
//=>클래스 나 구조체 또는 열거형 외부에서 함수를 호출할 때는 클래스 나 구조체 또는 열거형 이나 인스턴스를 통해서 호출합니다.
//=>static 이나 class 라는 키워드 없이 선언하면 인스턴스 메소드가 됩니다.
//인스턴스가 호출할 수 있는 메소드가 됩니다.
//인스턴스 메소드에는 숨겨진 매개변수인 self(자바의 this 와 동일)를 사용할 수 있습니다.
//=>self를 사용하는 경우는 메소드 내의 지역 변수 와 클래스 에 만든 프로퍼티의 이름이 동일할 때 프로퍼티를 호출할 때 사용합니다.
//동일한 이름이 2개 이상 존재하는 경우에는 가까운 곳에서 생성한 것을 호출합니다.
//
//지역 -> 클래스 -> 상위 클래스
//
//=>메소드 선언문 앞에 static을 붙이면 클래스가 호출할 수 있는 type 메소드가 됨
//type 메소드에서는 static 이나 class 가 붙은 프로퍼티를 제외하고는 사용할 수 없습니다.
//self 가 없기 때문입니다.
//
//=>static 메소드를 하위 클래스에서 오버라이딩 할 때는 static 대신에 class 라는 예약어를 사용해야 합니다.

class Sample1{
    var score:Int = 0
    
    //인스턴스 메소드
    func disp2() -> Void{
        //클래스에 선언한 score 와 동일한 이름의 지역변수
        let score = 50
        //이름만 작성하면 함수 내에서 찾고 없으면 클래스로 찾고 그래도 없으면 상위 클래스에서 찾음
        print("local 의 score:\(score)")
        //self를 붙이면 함수 내에서는 찾지 않습니다.
        print("instance 의 score:\(self.score)")
    }
    
    //클래스가 호출할 수 있는 메소드
    static func classMethod(){
        //self 가 없기 때문에 static 이나 class 가 없는 프로퍼티를 호출못함
        //print(score)
        
        print("Static Method")
    }
}

let sample1 = Sample1()
sample1.score = 90
sample1.disp2()

//클래스이름으로는 클래스 내부에 static 이나 class가 없는 메소드를 호출할 수 없습니다.
//Sample.disp()

Sample1.classMethod()

//static 메소드는 인스턴스를 이용해서 호출이 안됩니다.
//sample.classMethod()

//MARK: 5)selector
//=>Objective-C 에서 함수를 저장하기 위해서 사용하던 것
//=>함수를 대입할 때 #selector(함수이름(매개변수이름 나열)) 로 설정했고 매개변수가 없으면 함수 이름만 대입
//현재 iOS 나 Mac OS X API 에서는 메소드 앞에 @objc 가 붙은 경우에만 selector로 지정할 수 있습니다.


class Sample2{
    @objc func disp(){
        print("타이머")
    }
}

let sample2 = Sample2()
//일정한 주기를 가지고 함수를 호출하는 클래스 - Timer
Timer.scheduledTimer(timeInterval: 5, target: sample2, selector: #selector(Sample2.disp), userInfo: nil, repeats: true)


//MARK: 5)init - 초기화 메소드 : 생성자 와 유사한 역할
//=>인스턴스를 생성할 때 호출하는 메소드
//=>다른 메소드 와 다르게 독자적으로 호출되고 클래스 외부에서 호출
//=>init 은 만들지 않으면 매개변수가 없는 init()을 자동 생성해 줍니다.
//=>호출을 하면 heap 에 메모리 할당을 하고 init 안의 내용을 수행한 후 참조를 리턴합니다.
//=>직접 작성을 하는 경우 - func를 붙이지 않고 리턴 타입도 생략
//init(매개변수 나열){

//내용
//}
//=>함수 내에서 self 사용 가능
//=>overloading(매개변수의 개수 나 자료형을 다르게 해서 동일한 이름으로 메소드가 2개 이상 존재하는 경우) 가능
//=>직접 만들면 제공되는 매개변수가 없는 init은 소멸됩니다.


//=>self.init :  init 안에서 다른 init을 호출하고자 할 때 사용

//=>required init: 하위 클래스에서 반드시 재정의 해야 하는 init

//=>convenience init: 보조 init
//프로퍼티의 일부분을 매개변수로 받아서 자신의 init을 호출해서 초기화하는 init
//하위 클래스에 자동 상속

//=>init을 만드는 이유는 프로퍼티의 초기화가 목적인 경우가 많고 인스턴스를 만들 때 필수적으로 해야하는 작업이 있는 경우 생성

//MARK: 6)deinit
//=>인스턴스가 소멸될 때 호출되는 메소드
//=>매개변수가 없기 때문에 1개만 생성 가능

//MARK: 7)swift 에서 참조형의 메모리 관리
//=>인스턴스가 생성될 때 참조 카운트를 1로 만듭니다.
//=>인스턴스의 참조를 다른 변수에 대입할 때 참조 카운트를 1증가 시킵니다.
//=>인스턴스의 참조를 가지고 있는 변수에 nil을 대입하면 참조 카운트가 1감소 합니다.
//참조하고 있는 변수가 소멸되도 1 감소합니다.
//=>참조 카운트가 0이 되면 메모리 정리를 수행합니다.


/*
class Singer{
    var name : String = ""
    var gender : String = ""
    var birth : Int = 0
    //매개변수가 없는 init - default init
    init(){
        
    }
    
    init(name:String, gender:String, birth:Int){
        self.name = name
        self.gender = gender
        self.birth = birth
    }
    
    
    func disp(){
        print("이름은 \(name) 성별은 \(gender) 탄생은 \(birth)년")
    }
    
    deinit{
        print("인스턴스가 소멸될 때 호출됩니다.")
    }
}

//3개의 인스턴스를 생성해서 초기화
//nil을 저장할 수 있는 Optional로 선언
var adam : Singer? = Singer(name: "아담", gender: "남자", birth: 1998)
//adam.name = "아담"
//adam.gender = "남자"
//adam.birth = 1998

//Optional 경우는 메소드나 프로퍼티 호출할 때 wrapping을 제거해야 합니다.
adam!.disp()

//adam에 nil을 대입
adam = nil

//nil을 저장할 수 있는 자료형으로 선언
//!를 사용했기 때문에 사용할 때 !를 붙일 필요가 없습니다.
var lusia : Singer! = Singer(name: "류시아", gender: "여자", birth: 1998)
//lusia.name = "류시아"
//lusia.gender = "여자"
//lusia.birth = 1998
lusia.disp()

//lusia 의 참조를 imitation에 복사 - 참조 카운트가 1증가
var imitation = lusia
//nil을 대입해서 참조 카운트를 1감소 시켜도 메모리 정리가 발생하지 않음
lusia = nil
//참조 카운트를 1 감소 - 이제 참조 카운트가 0이 되서 deinit이 호출
imitation = nil

var cyda = Singer(name:"사이다", gender:"여자", birth:1998)
//cyda.name = "사이다"
//cyda.gender = "여자"
//cyda.birth = 1998
cyda.disp()
*/

//8)접근 지정자
//=>kotlin 이나 swift를 이용해서 스마트 폰 애플리케이션 제작할 때 는 잘 사용하지 않음

//open, public - 프로젝트 내의 모든 곳에서 접근 가능

//internal - 생략하면 기본으로 설정되는데  앱(모듈 내에서는 어디서든 접근 가는

//fileprivate - 파일 내에서만 접근 가능

//private - 클래스 나 구조체 안에서만 사용 가능


//4.상속
//=>하위 클래스가 상위 클래스의 모든 것을 물려받는 것
//=>swift 에서는 클래스 이름 뒤에 : 상위 클래스 이름 을 기재하면 됩니다.


//MARK: 상속, 프로퍼티

class Employee {
    var num : Int = 0
    
    //초기화 메서드 - 하위 클래스에서 초기화 메서드를 재정의 해야 합니다.
    init(num:Int) {
        self.num = num
    }
    
    func disp() -> Void {
        print("Employee 클래스")
    }
}

//Employee 클래스를 상속받은 Manager 클래스
class Manager : Employee {
    
    //초기화 메서드
    //동일한 모양의 init이 없으므로 재정의가 아닙니다.
    init() {
        super.init(num: 1)
    }
    
    //초기화 메서드
    //동일한 모양의 init이 존재하므로 재정의입니다.
    override init(num:Int) {
        //상위 클래스의 init 호출해야 합니다.
        super.init(num: num)
    }
    
    //메서드 오버라이딩
    override func disp() {
        print("Manager 클래스")
    }
}

//Employee 클래스를 상속받은 Manager의 인스턴스 변수 manager는 disp를 호출할 수 있습니다.
let manager : Manager = Manager()

manager.disp()

//Manager가 Employee의 하위 클래스
var employee : Employee = Employee(num: 10)
employee = Manager() //에러 없음 - 하위 클래스의 인스턴스는 상위 클래스 타입으로 만들어진 참조형 변수에 대입 가능합니다.

//var m1 : Manager = Employee(num:1) //에러 - 하위 클래스 타입으로 만들어진 참조형 변수에 상위 클래스 타입의 인스턴스를 대입할 수는 없습니다.

//강제 형 변환을 이용하면 대입 가능
var m1 : Manager = employee as! Manager

let em1 : Employee = Employee(num: 2)
//m1 = em1 as! Manager //에러는 아님 - 실행 중 예외를 발생시켜 중단됩니다.
//인스턴스가 Employee로 만들어졌기 때문에 에러

/*
class Starcraft {
    func attack() {}
}

class Terran : Starcraft {
    override func attack() {
        print("테란의 공격")
    }
}

class Protoss : Starcraft {
    override func attack() {
        print("프로토스의 공격")
    }
}

class Zerg : Starcraft {
    override func attack() {
        print("저그의 공격")
    }
}

//하위 클래스의 인스턴스를 상위 클래스의 참조형 변수에 대입할 수 있습니다.
//테란의 공격
var starcraft : Starcraft = Terran()
starcraft.attack()

//프로토스의 공격
starcraft = Protoss()
starcraft.attack()

//저그의 공격
starcraft = Zerg()
starcraft.attack()
*/

/*
//프로토콜 생성
protocol Starcraft {
    //메서드에 내용이 있으면 안됨
    func attack()
}

class Terran : Starcraft {
    func attack() {
        print("테란의 공격")
    }
}

class Protoss : Starcraft {
    func attack() {
        print("프로토스의 공격")
    }
}

class Zerg : Starcraft {
    func attack() {
        print("저그의 공격")
    }
}

//하위 클래스의 인스턴스를 상위 클래스의 참조형 변수에 대입할 수 있습니다.
//테란의 공격
var starcraft : Starcraft = Terran()
starcraft.attack()

//프로토스의 공격
starcraft = Protoss()
starcraft.attack()

//저그의 공격
starcraft = Zerg()
starcraft.attack()
*/


//프로토콜 생성
protocol Starcraft {
    //메서드에 내용이 있으면 안됨
    func attack()
}

class Terran {
   
}

//클래스 기능 확장 //Starcraft에서 제공하는 것만 구현하기
extension Terran : Starcraft {
    func attack() {
        print("테란의 공격")
    }
}

//하위 클래스의 인스턴스를 상위 클래스의 참조형 변수에 대입할 수 있습니다.
//테란의 공격
var starcraft : Starcraft = Terran()
starcraft.attack()

//MARK: 제너릭

//정수 2개의 자리 교체하는 함수
func swapInt(number1:inout Int, number2:inout Int) {
    let temp = number1
    number1 = number2
    number2 = temp
}

//실수 2개를 자리 교체하는 함수 생성
func swapDouble(number1:inout Double, number2:inout Double) {
    let temp = number1
    number1 = number2
    number2 = temp
}

var int1 : Int = 30
var int2 : Int = 20

swapInt(number1: &int1, number2: &int2)
print("int1:\(int1), int2:\(int2)")

var double1 : Double = 30.3
var double2 : Double = 20.2

swapDouble(number1: &double1, number2: &double2)
print("double1:\(double1), double2:\(double2)")


//제너릭 이용 //미지정 자료형 Number를 사용
func swap<Number>(number1:inout Number, number2:inout Number) {
    let temp = number1
    number1 = number2
    number2 = temp
}

//함수를 호출할 때 데이터를 대입하면 Number가 Int로 변경되어 수행합니다.
swap(number1: &int1, number2: &int2)
print("int1:\(int1), int2:\(int2)")
//함수를 호출할 때 데이터를 대입하면 Number가 Double로 변경되어 수행합니다.
swap(number1: &double1, number2: &double2)
print("double1:\(double1), double2:\(double2)")


//MARK: 문자열

let str : String = "Hello Swift"
//한 문자씩 출력
for ch in str {
    print(ch, terminator:"\t")
}
print()

//문자열 개수
print("문자의 개수:\(str.count)")

//바이트 배열로 변환해서 하나씩 접근
for ch in str.utf8 {
    print("\(ch)", terminator:"\t")
}
print()

//정적 배열
var languages = ["JavaScript", "Swift", "Java"]

var dbms : [String] = ["Oracle", "MySQL", "Mongo DB"]

//동적 배열
var frameworks = [String]()
frameworks.append("Spring")
frameworks.append("MyBatis")
frameworks.append("Hibernate")
frameworks.append("Node.js")

print("languages:\(languages)")
print("frameworks:\(frameworks)")
print("frameworks 3번째 데이터:\(frameworks[2])")

//dbms의 데이터 순회
for db in dbms {
    print("\(db)")
}

//배열 내의 데이터 정렬(오름차순)
languages.sort()
print(languages)

//배열을 복사한 후 정렬을 해서 리턴
var arrayResult = Array.sorted(dbms) //원본에는 아무런 변화가 없음
print(arrayResult)
print(dbms)

//배열 내의 데이터 정렬(내림차순) - 클로져 이용해서 대입
//languages.sort(by:{(number1:String, number2:String) -> Bool in return number1 > number2})

//배열 내의 데이터 정렬(내림차순) - 테레이링 클로져 이용해서 대입
//languages.sort() {(number1:String, number2:String) -> Bool in return number1 > number2}
//매개변수 생략 - $0는 첫번째 매개변수이고 $1은 두번째 매개변수
//languages.sort() {$0 > $1}

//배열 내의 데이터 정렬(내림차순) - 함수를 이용해 설정
func compare(number1:String, number2:String) -> Bool {
    return number1 > number2
}
languages.sort(by: compare)

print(languages)

var data = [100, 78, 77, 98]


//MARK: map
//각 data 배열의 숫자에 5를 더한 배열을 생성
print(data.map() {(number:Int) -> Int in return number + 5}) //원본 회손하지 않음


//MARK: filter
//data 배열에서 짝수만 골라내기
print(data.filter() {(number:Int) -> Bool in return number % 2 == 0}) //원본 회손하지 않음


//MARK: reduce
//data 배열 합계구하기  - 0은 기본값, number1은 누적값, number2는 각각의 데이터
print(data.reduce(0) {(number1:Int, number2:Int) -> Int in return number1 + number2}) //원본 회손하지 않음

//MARK: Set - NSSET, NSMutableSet
//데이터를 중복없이 해싱을 이용해서 저장
//데이터가 내부적으로 연산을 수행해서 저장 위치를 결정하기 때문에 데이터의 저장 순서는 알 수 없음
//swift에서는 Set을 만들고자 하는 자료형은 Hashtable 프로토콜을 conform 해야하고 == 연산자와 hash(into hash: inout Hasher)를 구현해야 함
//직접 생성하는 경우는 드물고 스마트폰 API에서 터지 관련 데이터 메소드들이 Set으로 전달함(ios에서는 위치 정보도 Set으로 전달)
//메모리 낭비는 심하지만 조회는 가장 빠름

var skills:Set<String> = ["JavaScript", "Swift", "Oracle", "Spring Framework", "Java", "Oracle"]

//저장한 순서와 출력 순서가 다름, 중복은 한번만 출력("Oracle"이 두개지만 한번만 출력됨)
for skill in skills {
    print(skill)
}
print(skills.dropLast())


//MARK: Tuple
//여러 개의 데이터 모임
//데이터 타입과 상관없이 데이터를 모아서 관리하는 자료형
//한번 생성되면 수정하거나 삭제하거나 추가할 수 없음
let skill = ("Java", 0, 8.7) //튜플
print(skill.0) //튜플의 경우 [0]가 아니라 .0로 인덱스 데이터 꺼냄

let technic = (language:"Java", dbms:"Oracle") //튜플 - 이름을 부여해서 저장
print(technic.language) //튜플의 이름으로 데이터 꺼냄

//튜플의 자료형에 별명을 부여
typealias Record = (number:Int, name:String)
//record 목록 만들기
var recordList = [Record]()
//데이터 삽입
recordList.append((number:1, name:"Java"))
recordList.append((number:2, name:"Swift"))
//데이터 순회
for record in recordList {
    print(record)
}


//MARK: Dictionary
//Key와 Value를 쌍으로 저장하는 자료구조 - 다른 언어에서는 Map이나 HashTable이라고도 함.
//Key의 자료형과 Value의 자료형은 모두 일치해야 함.
//Key의 자료형은 특별한 경우가 아니면 String
//Value의 자료형은 특별한 경우가 아니면 Any
/*
//데이터를 표현하기 위한 자료형 생성 - 관계형 데이터베이스(RDBMS)
var singer = [String:Any]()

//데이터 저장
singer["name"] = "adam"
singer["year"] = 1998
singer["company"] = "아담 소프트"

print(singer["name"] as! String) //데이터 가져올 때는 원래 자료형으로 형 변환 해야함

//데이터 추가 및 갱신
singer["face"] = "원빈" //없는 키라서 추가됨
singer["year"] = 1999 //존재하는 키라서 갱신됨

//전체 데이터를 조회 - 속성의 이름을 사용하지 않고 전체 데이터를 출력
for (key, value) in singer {
    print("\(key) : \(value)")
}

//데이터를 표현하기 위한 자료형 생성
class DTO {
    var num:Int = 0
    var name:String = ""
}

//데이터 생성
var dto = DTO()
dto.num = 1
dto.name = "아담"

//데이터 출력
print("번호: \(dto.num)")
print("이름: \(dto.name)")
*/

//Dictionary는 keys 라는 속성을 이용하면 key의 모든 키를 컬렉션으로 리턴
//values를 이용하면 모든 값을 컬렉션으로 리턴
//NoSQL
var singer = [String:Any]()

//데이터 저장
singer["num"] = 1
singer["name"] = "아담"

for key in singer.keys {
    print("\(key) : \(singer[key]!)")
}

/*
//2개의 배열
var redvelvet = ["아이린", "조이", "슬기", "예리"]
var blackpink = ["로제", "제니", "지수", "리사"]

//배열의 배열 - 배열은 인덱스를 가지고 저장
var girlgroups = [redvelvet, blackpink, itzy]
print(girlgroups)

var idx = 0
for girlgroup in girlgroups {
    if idx == 0 {
        print("레드벨벳", terminator:"\t")
    } else {
        print("블랙핑크", terminator:"\t")
    }
    
    for singer in girlgroup {
        print(singer, terminator:"\t")
    }
    print()
    idx = idx + 1
}
var itzy = ["예지", "유나"] //새로운 배열을 추가하려면 for문을 고쳐야함 - 유지보수 문제
*/

//MARK: mvc패턴 - 딕셔너리를 이용

//2개의 배열
var redvelvet = ["아이린", "조이", "슬기", "예리"]
var blackpink = ["로제", "제니", "지수", "리사"]

//배열의 배열 - 배열은 인덱스를 가지고 저장
var dict1:Dictionary<String, Any> = ["team":"레드벨벳", "singer":redvelvet]
var dict2:Dictionary<String, Any> = ["team":"블랙핑크", "singer":redvelvet]

//새로운 배열을 추가시
var itzy = ["예지", "유나"]
var dict3:Dictionary<String, Any> = ["team":"ITZY", "singer":itzy]

var girlgroups = [dict1, dict2, dict3]

for girlgroup in girlgroups {
    print("\(girlgroup["team"]!)", terminator:"\t")
    let singers = (girlgroup["singer"] as! NSArray) as Array
    for singer in singers {
        print("\(singer)", terminator:"\t")
    }
    print()
}


//MARK: 예외 처리(Expression Handling)

//문자열을 정수로 변환해서 num에 대입하고 출력
//Int가 정수로 변환하는데 실패하면 예외가 발생하는데 예외가 발생하면 nil을 리턴
//try?는 예외가 발생하면 nil을 리턴하고 try!는 예외가 발생하지 않을 거라는 확신을 가지고 강제 실행
var expressionNum : Int? = try? Int("jk1234")

if expressionNum != nil {
    print(expressionNum!)
}

func expressionMethod() {
    print("1")
    //이 문장은 이 메소드가 정상 수행된 후 호출됩니다.
    defer {
        print("2")
    }
    print("3")
}

expressionMethod()
print("4")

var expressionNum1 = 20

//조건을 주고 메시지를 설정해서 조건을 만족하지 않으면 메시지를 출력하고 애플리케이션 중단
assert(expressionNum1>100, "num1이 100보다 커야 합니다.")

print(expressionNum1)
