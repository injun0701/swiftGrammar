import UIKit

let rect = CGRect(x: 1, y: 1, width: 100, height: 100)

// print : 메시지를 출력해주는 함수
print(rect)
// dump : print보다 좀더 디테일하게 출력
dump(rect)


//MARK: 이름 생성 규칙

// 영문, 숫자, 한글, 한자, 특수문자, 이미지 용 바이너리 코드 모두 사용 가능
// 예약어는 사용할 수 없지만 예약어를 작은 따옴표 나 큰 따옴표로 감싸면 가능
// 연산자는 이름으로 사용할 수 없습니다.
// 숫자로 시작할 수 없으며 특수문자는 _로만 시작 가능
// 중간에 공백은 안됨


//MARK: Escape Sequence(제어문자)
// \다음에 영문자 나 기호 하나를 추가해서 특별한 의미를 부여한 문자
// \n : 줄 바꿈
// \t : 탭
// \r : 캐리지 리턴 - 커서를 맨 앞으로 옮겨 줍니다. \n 으로 줄바꿈에 안되면 \r\n 이라고 설정
// \0: null - nil(swift)
// \\, \’, \”: \, ‘, “


//MARK: 산술 연산자
// %, *, /, +, -
// 숫자 데이터만 사용할 수 있는 연산자로 %는 정수만 가능(실수에서 나머지를 구하고자 할 때는 truncatingRemainder 메소드 이용)
// 숫자 데이터의 자료형이 다르면 연산이 불가능하므로 형 변환을 해서 수행
// % 가 나머지 구해주는 연산자인데 주기적인 작업을 반복할 때 이용

// 짝수와 홀수를 1초에 한번씩 번갈아가면서 출력
for i in 1...10 {
    if i % 2 == 1 {
        print("홀수")
    } else {
        print("짝수")
    }
    sleep(1)
}

// 빨강 파랑 검정을 1초마다 번갈아가면서 10번 출력
for i in 1...10 {
    if i % 3 == 1 {
        print("빨강")
    } else if i % 3 == 2 {
        print("파랑")
    } else {
        print("검정")
    }
    sleep(1)
}


//MARK: Overflow, Underflow
// Overflow : 저장하고자 하는 범위를 위쪽으로 넘어선 경우
// Underflow : 저장하고자 하는 범위를 아래쪽으로 넘어선 경우

// &+, &-, &*를 이용하면 Overflow 나 Underflow가 발생했을 때 반대편 끝 숫자로 이동해서 처리 - 앞쪽의 비트를 제거하고 연산
var x : Int32 = 2100000000
var y : Int32 = 1000000000

// 숫자의 표현범위를 넘어서서 에러가 발생
// var OverflowResult : Int32 = x + y

// Overflow가 발생하면 앞의 숫자로 돌아가서 계속 진행
var OverflowResult : Int32 = x &+ y

print(OverflowResult)


//MARK: 비교 연산자
// >,>=, <, <= : 크기 비교 연산자
// ==, !=, ===, !== : 항등 연산자 - 동일성 여부

// 크기 비교는 숫자 데이터와 문자 데이터 에서만 가능
// 문자 데이터는 코드 값을 가지고 저장이 되기 때문에 코드 값을 가지고 크기 비교가 가능함
// 숫자(48 부터 시작) < 대문자(65 부터 시작) < 소문자(97부터 시작)
print("swift" < "SWIFT") //소문자가 크기 때문에 false

let str1 = NSString(format: "%@", "Hi Adam")
let str2 = NSString(format: "%@", "Hi Adam")

// ==는 값을 비교하는 연산자(가르키는 곳의 값이 같은지 비교)
// ===는 참조를 비교한는 연산자(가르키는 곳이 같은지 비교)

//2개의 내용이 같은지 비교
print(str1 == str2) //true

//2개의 참조가 같은지 비교
print(str1 === str2) //각각 초기화 메서드를 이용하기 때문에 참조는 같을 수도 혹은 다를 수도 있음

//범위 ~= 데이터 : 데이터가 범위 안에 속하면 true 아니면 false를 리턴
print(1...100 ~= 50) //true
print(1...100 ~= 150) //false


//MARK: 조건 논리 연산자
// !, &&, ||
// ! : Bool 데이터의 값을 변경하는 연산자 , true->false, false->true
// &&(and) : 2개의 값이 모두 true 일 때 만 true를 리턴하고 그 이외의 경우는 false를 리턴
// ||(or) : 2개의 값이 모두 false 일 때 만 false를 리턴하고 그 이외의 경우는 true를 리턴
// and의 경우는 첫번째 데이터가 false 이면 뒤의 데이터 값에 상관없이 false 이므로 뒤의 데이터를 확인하지 않음
// or의 경우는 첫번째 데이터가 true 이면 뒤의 데이터 값에 상관없이 true 이므로 뒤의 데이터를 확인하지 않음
// &&와 || 는 데이터의 순서는 변경해도 결과는 같음
// &&가 || 보다 우선순위가 높음

// 1~100까지 3의 배수이면서 4의 배수인 데이터를 출력
for i in 1...100 {
    // &&는 앞의 데이터가 true이면 뒤의 데이터를 확인
    // i % 3이 true인 경우는 33번
    if i % 3 == 0 && i % 4 == 0 {
        print("\(i)는 3의 배수이면서 4의 배수")
    }
}
print("========================")
for i in 1...100 {
    // i % 4이 true인 경우는 22번
    if i % 4 == 0 && i % 3 == 0 {
        print("\(i)는 3의 배수이면서 4의 배수")
    }
}


//MARK: 비트 논리 연산자
// 정수 데이터를 2진수로 변환해서 비트 단위로 연산을 수행하는 연산자
// ~ : 1의 보수를 구해주는 연산자 - 1의 보수는 0은 1로 1은 0으로 변환하는 것
// ~은 1의 보수를 구해주는데 숫자 데이터를가지고 하면 절대값이 1 커지거나 작아지면서 부호가 변경됩니다.

// & : 둘 다 1일 때만 1이고 나머지 경우는 0

// | : 둘 다 0일 때만 0이고 나머지 경우는 1

// ^(eXclusive OR) : 두 개의 비트가 같으면 0 이고 다르면 1

// << : 왼쪽의 데이터를 오른쪽의 숫자만큼 왼쪽으로 이동

// >> : 왼쪽의 데이터를 오른쪽의 숫자만큼 오른쪽으로 이동

// 그래픽 프로그래밍 이나 임베디드 프로그래밍, 시스템 프로그래밍에서 많이 이용
// 23 : 00000000 00000000 00000000 00010111
// 24 : 00000000 00000000 00000000 00011000
// 23 & 24 :  00000000 00000000 00000000 00010000  -> 16
// 23 | 24 :   00000000 00000000 00000000 00011111 -> 16 + 8 + 4 + 2 + 1 : 31
// 23^24 :   00000000 00000000 00000000 00001111 -> 8 + 4 +  2 + 1 : 15
// 23 << 2 : 00000000 00000000 00000000 01011100 -> 64 + 16 + 8 + 4 : 92 -> 23 * 4
// 23 >> 2 : 00000000 00000000 00000000 00000101 -> 4 + 1 -> 5 -> 23 / 4(나머지 소멸)
print(~23) // -24 양수는 절대값이 1증가
print(~(-23)) // +22 음수는 절대값이 1감소
print(23 & 24)
print(23 | 24)
print(23 ^ 24)
print(23 << 2)
print(23 >> 2)

// 그래픽 프로그램에서 그림을 그릴 때 페인트 모드가 있는데 XORPen, NOTXORPen 등이 있습니다.

// 선을 그리고 따라서 선을 그리면 선이 지워집니다.
// 기존 선에 NOTXORPEN 을 이용해서 합성해서 그립니다.
// 2개의 선의 데이터가 동일하기 때문에 결과는 모두 1이 됩니다. 색상은 모두 1이면 흰색입니다.

// 시스템 프로그래밍에서 삭제 작업(Masking)은 0 과의 AND 입니다.
// 데이터 복사 작업이나 쓰기 작업은 기존 디스크에 데이터 와 OR 합니다.

// ~은 1의 보수를 구해주는데 절대값이 1증가하거나 감소하고 부호가 반대로 됩니다.
// 컴퓨터는 2의 보수 방법을 이용해서 음수를 저장하고 2의 보수는 1의 보수 + 1 이기 때문입니다.


//MARK: 삼항 연산자
// Bool이 나오는 표현식 ? 참일 때 표현식 : 거짓일 때 표현식
// 제어문의 if와 유사한 역할이지만 연산자입니다.
// 조건에 따라 대입받는 값이 다를 때 많이 이용

//MARK: 복합 할당 연산자
// 연산자 =을 붙이는 구조인데 왼쪽의 변수에 저장된 데이터와 오른쪽의 데이터를 연산자로 연산을한 후 왼쪽의 변수에 대입합니다.

var n : Int = 19

n += 2 //x = x + 2 -> 21이 x에 저장됩니다.

// swift 에는 ++, — 가 없어졌습니다. (Swift 3에서 제거됨)


//MARK: Optional(nil을 저장할 수 있는 데이터) 연산자
// Optional! : 강제로 값을 추출
// Optional? : 안전하게 값을 추출


//MARK: nil 연산
// 표현식1 ?? 표현식2
// 표현식1이 nil 이면 표현식2를 반환
// 기본값 설정에 많이 이용
var nilInt : String? = nil
let resultNilInt = nilInt ?? "nil이네요"
print(resultNilInt)


//MARK: 범위 연산자
// 시작숫자. . .종료숫자: 시작숫자부터 종료숫자까지
// 1~100까지 3의 배수이면서 4의 배수인 데이터를 출력
for i in 1...10 {
   print(i)
}
// 시작숫자. . <종료숫자: 시작숫자부터 종료숫자 이전까지
for i in 1..<10 {
   print(i)
}
// 숫자를 감소시키고자 할 때는 reversed()를 호출 : (시작숫자. . .종료숫자).reversed()
for i in (1...10).reversed() {
   print(i)
}


//MARK: 제어문
//자료형 명시
let score : Int = 79
//자료형 추론
let year = 2021

//MARK: if문
// score가 60 이상이면 합격이라고 출력
// 등가분할 테스트(Equivalence Partitioning)
if score >= 60 {
    print("합격")
}

// year가 윤년이면 "윤년" 출력하고 아니면 "윤년이 아님" 출력
// 윤년 - 4의 배수이고 100의 배수는 아닌 경우 또는 400의 배수인 경우
if year % 4 == 0 && year % 100 != 0 || year % 400 == 0 {
    print("\(year)은 윤년")
} else {
    print("\(year)은 윤년이 아님")
}

// score가 90 이상 100이하이면 A
// 80 이상 90미만이면 B
// 70 이상 80미만이면 C
// 60 이상 70미만이면 D
// 0 이상 60미만이면 F
if score >= 90 && score <= 100 {
    print("A")
} else if score >= 80 && score < 90 {
    print("B")
} else if score >= 70 && score < 80 {
    print("C")
} else if score >= 60 && score < 70 {
    print("D")
} else if score >= 50 && score < 60 {
    print("F")
} else {
    print("잘못된 점수")
}
// 위에 제어문은 경계값 분석(BOUNDARY VALUE ANALYSIS)을 통해 테스트해봐야 함
// 경계값 분석(BOUNDARY VALUE ANALYSIS) - 테스트 아이템의 입력 또는 출력이 여러 영역으로 구분되는 경우에 적용 입력 또는 출력 조건의 경계를 기준으로 데이터를 선택해 테스트하는 기법

// TDD : 테스트 주도 개발
// Agile : 프로그램을 분할해서 반복적인 개발 - 고객의 니즈 변화를 빠르게 적요ㅛㅇ하기 위해서 짧은 주기를 가지고 프로그램을 분할해서 정복한 후 다음 작업을 진행하는 방식
// Code Review : 작성한 코드를 분석해서 문제점을 찾아내는 것 - Code Optimizing하거나 Customizing을 수행

//MARK: switch문
/*
switch 표현식 {
case match1:
    표현식이 match1일때 수행할 내용
case match1:
    표현식이 match1일때 수행할 내용
default:
 일치하는 값이 없을 때 수행
}
*/
// 표현식의 데이터가 enum이 아니면 default 생략 불가능
// 표현식의 결과가 어떤 값과 match가 되면 break됨(스위프트에서는 break를 쓰지 않는다)
// 아래로 내려가고자 하는 경우 fallthrough를 입력해야함
// case에 하나의 값 이상 표현 가능 -,로 구분하거나 범위 연산자(..., ..<)를 이용

// case에 where를 추가 가능
// 비교 대상에 튜플(여러 데이터의 모임 - 데이터 종류에 상관없음) 사용 가능

// 가장 일반적인 경우
let menu = 1

// menu의 값이
// 1이면 나주식당
// 2이면 난향
// 3이면 신촌설렁탕
switch menu {
case 1:
    print("나주식당")
case 2:
    print("난향")
case 3:
    print("신촌설렁탕")
default:
    print("편의점")
}

// case에 where을 추가해서 조건을 추가하는 것이 가능
// score가 90 이상 100이하이면 A
// 80 이상 90미만이면 B
// 70 이상 80미만이면 C
// 60 이상 70미만이면 D
// 0 이상 60미만이면 F
switch score {
case 90...100:
    print("A")
case 80..<90:
    print("B")
case 70..<80:
    print("C")
case 60..<70:
    print("D")
case 0..<60:
    print("F")
default:
    print("잘못된 점수")
}

//MARK: for문
// 데이터 모임을 순회할 때 사용
/*
for 임시변수 in 데이터 모임 또는 범위 {
    데이터모임을 순회하면서 수행할 작업
}
*/
for i in 0...2 {
    print(i)
}

// 범위의 값을 대입하지 않고 실행
for _ in 0...2 {
    print("임시변수 이용하지 않고 순회")
}

var li = ["CBD", "TDD", "Agile"]
for swengineering in li {
    print(swengineering)
}


//MARK: while문
/*
while 표현식 {
    수행할 내용
}
 표현식의 결과가 false가 아니라면 수행할 내용을 반봅
*/

var i=0
while i <= 2 {
    print("반복 수행")
    i = i + 1
}

//MARK: repeat while문
/*
repeat {
    수행할 내용
} while 표현식
 표현식의 결과가 false가 아니라면 수행할 내용을 반봅
*/

//MARK: guard문
// 표현식이 거짓일 때 수행할 문장을 작성하는 제어 명령어
/*
guard 표현식 else {
    수행할 내용
}
*/
// 표현식이 false일 때 수행할 내용을 작성
// else 안은 종료하는 문장을 작성
// 조건에 맞지않으면 준단하겠다는 의미로 사용

let os = 9.0

//if는 흐름을 이어가는데 분기를 해야할 때 사용
if os < 11.0 {
    print("11.0 보다 작음")
}

//guard는 함수 안에 포함되어야 함
//흐름을 중단 시키기 위해 사용 (if하고 반대로 작용)
func function() {
    guard os >= 11.0  else {
        print("11.0 보다 작음")
        return
    }
}
function()

//MARK: 운영체제 버전 확인
print("윤영체제 버전: \(UIDevice.current.systemVersion)")

//특정 운영체제 이상에서 동작하기
if #available(OSX 11.0, *) {
    print("11.0 이상에서 동작")
} else {
    print("11.0 미만에서 동작")
}

//MARK: Optional
// Swift 나 Kotlin에서는 자료형을 구분할 때 nil을 저장할 수 있는 자료형과 그렇지 않은 자료형으로 구분
// nil을 저장할 수 있는 자료형을 Optional이라고 함
// null 안정성 때문에 제공

// Optional 자료형이 아닌경우 NullPointerExcetion이 발생하지 않음
var notOptional : Int = 123

// Optional 자료형
var optional : Int? = nil

// Optional 자료형과 Optional 자료형이 아닌경우는 연산이 불가능
// print(notOptional + optional) //error

// Optional 사용
// 1)명시적 해제 - 강제 해제
// =>강제로 Optional을 벗겨내는 것으로 Optional 데이터 뒤에 !를 붙이면 됩니다,
// =>저장된 데이터가 nil 이라면 에러가 발생합니다.
// 이 방법을 사용할 때는 nil 인지 확인하고 사용하는 것이 좋습니다.

// 2)명시적 해제 - 비강제 해제
// =>Optional Binding 이라고 하는데 if 나 guard 구문에서 다른 변수에 대입을 하게되면 nil 이 아니면 true를 리턴하고 nil 이면 false를 리턴하므로 true 일 때 사용하는 방식입니다.

// Optional 변수 생성
var optionaX : Int! =  32
print("x:\(optionaX)")
// Optional을 강제로 해제하고 사용
print("x:\(optionaX!)")

optionaX = nil
// nil 이 있는 데이터를 강제로 변경해서 연산에 사용하면 에러
// nil 인지 확인하고 강제 변환을 해야 합니다.
if optionaX != nil{
    let optionaXResult = optionaX! + 20
    print("optionaXResult:\(optionaXResult)")
}else{
    print("optional가 nil 이라서 연산에 사용할 수 없습니다.")
}


// Optional 데이터를 if 구문의 표현식에서 다른 변수에 대입해서 해제
// 변수에 대입을 하게 되면 nil 이 아니면 true를 리턴하고 nil 이면 false 리턴
if let optionaY = optionaX{
    print("optionaY:\(optionaY)")
}else{
    print("optionaX는 nil")
}

// 3)컴파일러에 의한 자동 해제
// => == 또는 != 연산자를 이용할 때는 자동으로 해제해서 비교를 수행합니다.

// 4)변수를 선언할 때 ? 대신에 ! 연산자를 이용해서 선언하면 사용할 때 해제를 하지 않아도 자동으로 해제가 됩니다.
var optionaX2 : Int? = 123

// == 연산자 나 != 연산자를 사용할 때는 Optional을 강제로 해제하지 않아도 됩니다.
if optionaX2 == 123{
    print("2개의 데이터는 일치합니다.")
}else{
    print("2개의 데이터는 일치하지 않습니다.")
}

// 사용할 때 자동으로 !를 해제해서 사용하도록 변수를 생성
var optionaY2 : Int! = 123
//x는 ?를 붙여서 선언한 것으로 !로 해제해서 사용
//y는 !를 붙여서 선언한 것으로 !를 해제하지 않아도 됩니다.
print(optionaX2! + optionaY2)

//nil 연산자
//데이터가 nil 이면 뒤의 데이터를 사용하고 nil 이 아니면 원본 데이터 사용
print(optionaX2 ?? 256)
optionaX2 = nil
print(optionaX2 ?? 256)

// **특수 자료형
//1.Any
//=>모든 데이터의 참조를 저장하기 위한 자료형으로 Objective-C 의 자료형

//2.AnyObject
//=>모든 인스턴스(클래스로부터 생성된 것)의 참조를 저장하기 위한 자료형으로 Objective-C 의 자료형

//3.Any 나 AnyObject 에 저장할 때는 아무 데이터나 저장할 수 있지만 사용을 할 때는 강제 형 변환을 해서 사용해야 합니다.

//4.Selector
//=>Objective-C에서 사용하던 것으로 함수를 저장하기 위해서 사용
//=>Swift 에서는 이 자료형이 필요가 없습니다.
//Swift 는 함수형 프로그래밍 언어라서 함수 자체가 하나의 자료형입니다.
//Objective-C API 에서 사용 - 콜백 메소드 지정하는데 사용

//5.Never
//=>함수의 리턴 타입으로만 사용되는 자료형으로 함수가 정상적으로 리턴하지 않을 수 도 있다라는 의미를 전달하기 위해서 사용

var optionaX3 : Any = 123

//Any 자료형의 데이터는 사용을 할 때 원래의 자료형으로 되돌려서 사용해야 합니다.
//이 때는 as , as?, as! 를 이용합니다.
//print(optionaX3 + 256)
print((optionaX3 as! Int) + 256)

// **함수
//=>독립적으로 메모리를 할당받아 수행되는 작은 프로그램 - 단독으로 존재할 수 없고 파일이나 클래스 안에 존재해야 합니다.
//클래스 안에 존재하면 Method 라고 합니다.

//1.분류
//=>사용자 정의 함수: 개발자가 필요에 의해서 만든 함수
//=>API(Application Programming Interface - Software Develpment Kit): 언어 나 프레임워크 제조사에서 제공해주는 함수
//=>3rd Party Function: 다른 개발자가 만들어서 제공하는 함수

//2.함수 와 메소드
//=>함수는 전역에 생성해서 모든 곳에서 호출이 가능
//=>메소드는 클래스 안에 만들어서 호출할 수 있는 범위가 한정적이고 호출을 하기 위해서는 클래스 나 인스턴스 와 같은 Receiver 가 필요합니다.

//3.함수의 구성
//1)이름: 함수를 구분하기 위한 이름
//2)매개변수(Parameter, Argument): 함수를 호출해서 실행할 때 넘겨주는 데이터
//3)반환형(Return Type): 함수의 수행이 끝나고 호출한 곳으로 돌아갈 때 가져가는 데이터의 자료형으로 없으면 Void 나 생략
//4)함수의 내용(body): 함수가 수행할 내용

//4.함수 작업 구조
//1)함수를 선언 - 생성

//2)함수를 호출 - 새로운 메모리 공간을 할당받아서 실행하고 결과를 리턴

//3)결과를 사용

//5.함수를 사용하는 이유
//1)코드의 중복을 제거해서 유지 보수를 쉽게 하기 위해서 - 변수, 반복문, 함수, 클래스, 상속의 공통된 이유

//2)적절하게 코드를 분리해서 가독성 높이고 메모리 효율을 증가시키기 위해서


//6.함수 선언 - 구현, 정의
//func 함수이름(매개변수이름:매개변수의  자료형, …..) -> 리턴 타입{
//    함수의 내용
//    return 데이터
//}
//=>매개변수는 없으면 생략 가능 - ( )는 남겨둠
//=>리턴되는 데이터가 없을 때는 Void 또는 -> 리턴 타입을 생략
//=>함수 내용은 없을 수 도 있지만 없으면 아무일 도 하지 않습니다.
//=>리턴 타입이 Void 이거나 생략되어 있으면 return 문장을 생략할 수 있고 return 만 사용할 수 도 있습니다.
//return 이후에는 실행문이 나오면 안됩니다.
//return 은 호출한 곳으로 돌아가는 명령어라서 메모리가 소멸됩니다.

//7.함수 호출
//변수 = 함수이름(넘겨줄 데이터 나열)
//=>함수를 선언할 때 만든 매개변수와 자료형을 일치시켜서 데이터를 넘겨주어야 합니다.
//=>리턴 타입이 없으면 변수에 대입하면 안됩니다.
//=>리턴되는 데이터가 있을 때 변수에 저장하지 않고 다른 명령어에 바로 사용해도 됩니다.

//매개변수가 없고 리턴이 없는 함수 생성
func disp(){
    for _ in 0..<5{
        print("Hello Swift")
    }
}

//매개변수가 없고 리턴이 없는 함수를 호출
disp()


//8.매개변수 - parameter, argument, query string(web)
//=>함수를 호출할 때 함수에게 넘겨주는 데이터
//=>매개변수는 함수 내에서만 사용할 수 있는 지역 변수로 생성되고 읽기 전용으로 생성됩니다.
//=>함수에 따라서 없을 수 도 있으며 없을 때는 ( )만 합니다.
//=>swift 에서는 함수를 호출할 때 매개변수의 이름과 값을 같이 넘겨주어야 합니다.
//함수이름(매개변수이름:값..) 의 형태로 대입합니다.
//=>Apple 의 API의 매개변수의 이름을 길게 만듭니다.

//매개변수를 받아서 매개변수 만큼 출력해주는 함수
func disp(count:Int){
    for _ in 0..<count{
        print("Hello Function")
    }
}

//함수를 호출할 때 매개변수는 이름과 함께 설정합니다.
disp(count: 3)
disp(count: 5)

//매개변수가 2개 인 함수 - message를 count 횟수 만큼 출력해주는 함수
func disp2(message:String, count:Int){
    for _ in 0..<count{
        print(message)
    }
}

disp2(message: "매개변수가 여러 개", count: 2)

//1)Overloading(중복 정의)
//=>동일한 영역에 함수의 이름은 같고 매개변수의 개수나 자료형 또는 순서를 다르게 만든 함수가 2개 이상 존재하는 경우

//2)매개변수 이름에 별칭 사용
//=>외부에서 사용하는 이름 과 함수 내부에서 사용하는 이름을 다르게 만드는 것
//외부에서 보는 이름은 길게 사용자가 알아보기 쉽게 해주는 것이 좋고 내부에서 사용하는 이름은 짧게 하는 것이 코딩하는데 편리하기 때문입니다.

//func 함수이름(외부에서사용할이름 내부에서사용할이름 : 자료형….)

//3)외부에서 입력할 때 매개변수의 이름을 생략
//=>첫번째 매개변수는 작업을 위한 데이터일 때 가 많기 때문에 생략하도록 할 수 있습니다.
//=>매개변수 이름을 _로 하면 됩니다.
//내부에서 사용할 거라면 내부에서 사용할 이름이 반드시 있어야 합니다.

//외부에서는 message 와 count 라는 이름으로 매개변수를 대입
//내부에서는 msg 와 cnt로 매개변수를 사용합니다.
func disp3(message msg : String, count cnt:Int){
    for _ in 0 ..< cnt{
        print(msg)
    }
}

disp3(message: "외부에서 사용한 이름", count: 5)
//disp3(msg: "외부에서 사용한 이름", cnt: 5)
//에러 - 내부에서 사용하는 이름 사용 못함


//외부에서는 이름을 생략해서 msg를 대입
func disp4(_ msg:String){
    print(msg)
}

disp4("이름없이 매개변수 대입")
//=>매개변수 생략은 첫번째 데이터 1개만 사용하는 것이 일반적입니다.

//4)매개변수에 기본값 설정
//func 함수이름(매개변수이름:자료형 = 기본값…)
//=>매개변수를 생략하면 기본값이 설정됩니다.
//=>뒤에서부터 사용합니다.


//5)매개변수의 개수를 제한없이 설정
//func 함수이름(매개변수이름: 자료형 …)
//=>대입되는 개수를 설정하지 않은 것으로 여러 개 대입 가능
//=>내부에서는 매개변수이름을 데이터 집합으로 간주하기 때문에 for - in을 이용해서 데이터를 순차적으로 접근하는 것이 가능

//매개변수에 기본값을 설정한 함수
func disp5(message:String = "nomessage"){
    print(message)
}

disp5(message:"message")
//매개변수가 없어서 nomessage 출력
disp5()

//매개변수의 개수가 가변인 함수
func sum(data:Int...){
    var tot = 0
    for i in data{
        tot = tot + i
    }
    print(tot)
}

sum(data:10, 20)
sum(data:10, 20, 30)


//6)매개변수에 레퍼런스 전달
//=>매개변수는 읽기 전용으로 값이 전달되기 때문에 함수 안에서 외부에서 대입한 매개변수의 값을 변경할 수 없습니다.
//Call by Value 라고 합니다.
//=>함수 내부에서 함수 외부의 데이터를 변경하고자 할 때는 매개변수를 대입할 때 레퍼런스를 대입해주어야 합니다.
//Call by Reference 라고 합니다.
//=>함수를 만들 때 함수의 매개변수 앞에 inout을 추가합니다.
//=>함수를 호출할 때 매개변수 의 값 앞에 & 를 추가하면 됩니다.

//매개변수가 Value 형태로 대입받기 때문에 함수에서 외부의 데이터를 변경할 수 없음
func callByValue(arg:Int){
    //arg = 20 //읽기 전용으로 전달되므로 직접 변경하는 것은 에러
    var param = arg
    param = 20
    print("param:\(param)")
}

var referenceX : Int = 10

callByValue(arg: referenceX) //x가 대입된 것이 아니고 x의 데이터인 10이 대입된 것
print("referenceX:\(referenceX)")

//레퍼런스를 전달받는 함수
func callByReference(arg: inout Int){
    arg = 20
    print("arg:\(arg)")
}
callByReference(arg: &referenceX) //x의 참조가 전달 - //x의 값이 변경될 수 있음
print("referenceX:\(referenceX)")


//9.return
//=>return 은 함수의 수행을 종료하고 함수를 호출한 곳으로 제어권을 이동시키는 제어문

//1)return type
//=>함수를 호출하는 곳으로 제어권을 넘겨줄 때 가지고 가는 데이터의 자료형
//=>가지고 갈 데이터가 없으면 Void 또는 생략
//=>함수의 내용이 한 줄 이고 이 데이터를 리턴하는 경우 return을 생략할 수 있음


//2)return 은 1개만 가능
//=>여러 개를 리턴하고자 하는 경우는 데이터의 모임을 만들어서 리턴
//리턴이 있는 함수
func add(first:Int, second:Int) -> Int{
    return first + second
}

//리턴이 있는 함수는 호출 결과를 변수에 담아서 사용
var returnResult = add(first: 100, second: 300)
print("returnResult:\(returnResult)")

//10.Swift 에서 함수는 일급 객체
//=>함수도 하나의 자료형
//=>함수도 하나의 자료형 이므로 변수를 생성할 수 있고 다른 함수의 매개변수가 될 수 있고 함수의 리턴 타입이 될 수 있습니다.
//함수가 다른 함수의 매개변수가 되는 경우는 함수가 콜백으로 사용되는 경우입니다.
//콜백 함수는 이벤트가 발생했을 때 호출되는 함수입니다.

//=>함수의 자료형 표현
//(매개변수의 자료형, 매개변수의 자료형..) -> 리턴타입

//=>함수 안에 함수를 만들 수 도 있고 클래스를 만들 수 도 있습니다.

//=>순수 함수: 외부의 영향을 받지도 영향을 주지도 않고 리턴을 하는 함수 - 매개변수의 자료형이 Value Type으로 값을 전달받는 함수

//이 함수는 매개변수가 없고 리턴이 없는 함수를 매개변수로 요청
func callback(f:()->Void){
    f()
}

func method(){
    print("함수를 매개변수로 대입합니다.")
}

//함수를 매개변수로 대입해서 callback을 호출
callback(f:method)

//매개변수를 함수로 받는 함수
//정수 2개를 매개변수로 받고 정수를 리턴하는 함수가 매개변수
func ff(f:(Int, Int) -> Int){
    print(f(100, 200))
}


func add2(first:Int, second:Int) -> Int{
    return first + second
}

ff(f:add2)






